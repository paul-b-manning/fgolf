package com.gatorPaul.fgolf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FgolfApplication {

	public static void main(String[] args) {
		SpringApplication.run(FgolfApplication.class, args);
	}

}
