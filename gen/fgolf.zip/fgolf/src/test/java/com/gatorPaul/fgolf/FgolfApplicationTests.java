package com.gatorPaul.fgolf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FgolfApplicationTests {

	@Test
	void contextLoads() {
	}

}
